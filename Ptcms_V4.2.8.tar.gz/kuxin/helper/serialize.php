<?php

namespace Kuxin\Helper;

/**
 * Class Serialize
 *
 * @package Kuxin\Helper
 * @author  Pakey <pakey@qq.com>
 */
class Serialize
{
    
    /**
     * 序列化
     *
     * @param $data
     * @return string
     */
    public static function encode($data)
    {
        return serialize($data);
    }
    
    /**
     * 反序列化
     *
     * @param $data
     * @return mixed
     */
    public static function decode($data)
    {
        return unserialize($data);
    }
}